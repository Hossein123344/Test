# PC Academy — Physique-Chimie 1BAC

Site éducatif statique en français, conçu pour être publié gratuitement avec GitHub Pages.

## Contenu
- Fiches de cours Physique et Chimie avec fenêtres de lecture
- Recherche et filtres par matière
- Formules essentielles et unités
- Exercices avec corrections interactives
- Conseils de méthode
- Design responsive pour téléphone, tablette et ordinateur

## Publier sur GitHub Pages
1. Connecte-toi à https://github.com et crée un nouveau dépôt (par exemple `pc-academy-1bac`).
2. Ajoute `index.html` à la racine du dépôt.
3. Ouvre **Settings → Pages**.
4. Dans **Build and deployment**, choisis **Deploy from a branch**.
5. Sélectionne la branche `main` et le dossier `/ (root)`, puis clique sur **Save**.
6. Après quelques minutes, ton site sera disponible à l'adresse affichée dans la section Pages.

## Modifier le site
Tout le site se trouve dans `index.html`. Tu peux modifier les fiches dans le tableau JavaScript `lessons`, les formules dans la section `formules` et les exercices dans la section `exercices`.

## Note pédagogique
Ce site est une base de révision non officielle. Les chapitres présents sont des fiches de départ et ne remplacent pas le programme détaillé, le cours du professeur ou les manuels. Vérifie les chapitres exacts étudiés dans ta classe de 1ère Bac au Maroc.
